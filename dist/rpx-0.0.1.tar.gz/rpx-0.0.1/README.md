# rpx cli

a project cli with python
